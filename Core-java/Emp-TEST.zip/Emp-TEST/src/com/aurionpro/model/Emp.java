package com.aurionpro.model;

import java.io.Serializable;
import java.util.Date;

public class Emp implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private int id;
	private String name;
	private String designation;
	private int managerId;
	private Date DOJ;
	private int salary;
	private String commission;
	private int departmentId;
	
	public Emp(int id, String name, String designation, int managerId, Date dOJ, int salary, String commission,
			int departmentId) {
		super();
		this.id = id;
		this.name = name;
		this.designation = designation;
		this.managerId = managerId;
		DOJ = dOJ;
		this.salary = salary;
		this.commission = commission;
		this.departmentId = departmentId;
	}

	public Emp() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public Date getDOJ() {
		return DOJ;
	}

	public void setDOJ(Date dOJ) {
		DOJ = dOJ;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getCommission() {
		return commission;
	}

	public void setCommission(String commission) {
		this.commission = commission;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	@Override
	public String toString() {
		return "Emp [id=" + id + ", name=" + name + ", designation=" + designation + ", managerId=" + managerId
				+ ", DOJ=" + DOJ + ", salary=" + salary + ", commission=" + commission + ", departmentId="
				+ departmentId + "]";
	}
	
	
}
